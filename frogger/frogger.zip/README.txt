This assignment took me about eight hours to complete. Additional features implemented:

- dead frogger skull
- Fly that appears randomly and can only be gotten once per level +200 pts
- Levelling up - things move faster, cars get added.
- implemented a timer


