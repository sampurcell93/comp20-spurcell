var express = require('express');
var url = require('url');
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};
function compile(str, path) {
  return stylus(str)
    .set('filename', path)
    .set('compress', true)
    .use(nib());
}

var app = express();
var stylus = require('stylus');
var nib = require('nib');
var db = require("mongojs").connect("mongodb://heroku_app14956629:n5d3bdpdhj451kthiv66qv72b4@ds053877.mongolab.com:53877/heroku_app14956629", ["scores"]);

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
    // intercept OPTIONS method
    if ('OPTIONS' == req.method) {
      res.send(200);
    }
    else {
      next();
    }
};

app.configure(function (){
    app.use(allowCrossDomain);
    app.use(express.bodyParser());
    app.use(express.methodOverride());
    app.set('views', __dirname + '/views');
    app.set('view engine', 'jade');
    app.use(app.router);
    app.use(stylus.middleware({
        src: __dirname + '/views',
		dest: __dirname + '/public',
		compile: compile
	}));  
    app.use(express.static(__dirname + '/public'));
});

function badRequest(res) {
	res.end('{"status": "bad querystring"}');
}

app.post('/submit.json', function (request, res){
	var url_parts = url.parse(request.url, true);
	var query = url_parts.query;
	var score = parseInt(query.score);
	if ( 3 > Object.size(query))
		badRequest(res);
	if (!query.hasOwnProperty("game_title") ||
	  	!query.hasOwnProperty("score") || 
		!query.hasOwnProperty("username") || isNaN(score))
	{
			badRequest(res);
			return
	}
	var item = {
		username: query.username,
		score: score,
		created_at: new Date,
		game_title: query.game_title
	}
	var scores = db.collection('scores');
	scores.insert(item, {w:1}, function(err, result) {
		if (err){
			badRequest(res);
			console.log(err);
		}
	});
	res.end('{"status":"good request"}');
});

app.get('/highscores.json', function (request, res){
	var url_parts = url.parse(request.url, true);
	var query = url_parts.query;
	if (Object.size(query) < 1)
		badRequest(res);
	else if (!query.hasOwnProperty("game_title"))
		badRequest(res);
	db.scores.find({game_title: query['game_title']}).limit(10).sort({score:-1}, function(err, items) {
		console.log(err);
		res.end(JSON.stringify(items));
	});
});

app.get('/', function (request, res) {
	db.scores.find().sort({score:-1}, function(err, items) {
		res.render('index', {
			title: 'All Game HighScores', 
			scores: items
		});
	});
});

app.get('/usersearch', function(request, res) {
		res.render('users', {
			scripts: [
				'http://code.jquery.com/jquery-1.9.1.min.js',
				'ajax.js'
			]
		});
});


app.get("/userscores", function(req, res) {
	var url_parts = url.parse(req.url, true);
	var query = url_parts.query;  
	db.scores.find({username: query.username}).sort({score: -1}, function(err, items) {
		res.writeHead(200,
			{
  				"Access-Control-Allow-Origin": "*",
                "access-control-allow-methods": "GET, POST, PUT, DELETE, OPTIONS",
                "access-control-allow-headers": "content-type, accept",
                "access-control-max-age": 10, // Seconds.
				"Content-Type": "application/json",
            }
		);
	    res.end(JSON.stringify(items));
	});
});

app.listen(process.env.PORT || 3000);
