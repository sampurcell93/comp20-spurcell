$(document).ready( function () {
	var curr = -1;
	$('button').on('click', function() {
		var v = $("input").val();
		//check that they're not clicking over and over
		if (curr == v || v == "") return;
		curr = v;
		$.getJSON('/userscores', {username: v}, function(json){
  			$(".scores").empty();
  			for (var i in json){
  				$("<li />").html(
  					"<span>" + json[i].score + "</span>" + 
  					"<span>" + json[i].username + "</span>" +
  					"<span>" + json[i].game_title + "</span>"
  				).appendTo(".scores").hide().slideDown("fast");
  			}
  			if (!json.length)
  				$("<li />").text("No results found for that user!").addClass("error").appendTo(".scores");
		});
	});
});